<?php

session_start();

  include("connection.php");
  include("functions.php");

  if($_SERVER['REQUEST_METHOD'] == "POST")
  {

    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
    {


      $query = "select * from korisnik where korime = '$user_name' limit 1";
      $result = mysqli_query($con,$query);
      if($result){
        if($result && mysqli_num_rows($result) > 0)
        {
          $user_data = mysqli_fetch_assoc($result);

          if($user_data['lozinka'] === $password)
          {
            $_SESSION['user_id'] = $user_data['korisnik_id'];
            header("Location: index.php");
            die;

          }
        }
      }
        echo "Wrong username or password";
    }else
    {
        echo "Wrong username or password";
    }

  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
  <div>
    <form action="login.php" method="post">
      <div class="container-fluid h-100">

        <div class="row justify-content-center align-items-center h-100">
          <div class="col col-sm-6 col-md-6 col-lg-4 col-xl-3">
            <h1 class='text-center'>Login</h1>
            <hr class="mb-3">
            <label for="user_name"><b>Username</b></Label>
            <input class="form-control" id="user_name" type="text" name="user_name" required>

            <label for="password"><b>Password</b></Label>
            <input class="form-control" id="password" type="password" name="password" required>
            <br>
            <div class='text-center'>

              <input class="btn btn-primary" id="login" type="submit" name="create" value="Login">

              <a href="index.php" class="btn btn-secondary">Continue as guest</a>
            </div>
          </div>
        </div>
      </div>
  </form>
</div>
<script src="script.js"></script>

</body>
</html>
