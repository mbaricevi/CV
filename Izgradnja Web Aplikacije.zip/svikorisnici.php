<?php
session_start();

    include("connection.php");
    include("functions.php");
    $user_data = check_login($con);

    if(empty($user_data) || (!empty($user_data) && $user_data['tip_korisnika']!=0))
    {
      printf("You do not have access to this page.");
      exit();
    }
    if(isset($_GET['pageno']))
    {
      $pageno = $_GET['pageno'];
    }
    else
    {
      $pageno = 1;
    }

    $korisnici = allKorisnici($con);
    $broj_korisnici = mysqli_num_rows($korisnici);
    $korisnici_per_page = 12;
    $brojStr_offset = $pageno - 1;
    $offset = $brojStr_offset * $korisnici_per_page;
    $total_pages = ceil($broj_korisnici / $korisnici_per_page);
    $korisnici = allKorisnici($con, $korisnici_per_page, $offset);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, inital-scale=1.0">
<title>IWA</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
<link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php">Naslovna</a><li>
          <li><a href='pjesme.php'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php' class='active'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>

<section id="product1" class="section-p1">
  <a href="newkorisnik.php">
    <button id ="ctasong2"><strong> Dodaj novog korisnika</strong></button>
  </a>
  <div class="pro-container">
    <?php
    while($row = mysqli_fetch_array($korisnici))
    {
      $korisnik = "
        <div class='pro'>
          <div class='des'>
            <h5>".$row['ime']."  ".$row['prezime']."</h5>
              <span><strong>Tip korisnika: </strong>".$row['tip_korisnika_naziv']."</span><br>
              <span><strong>Korisničko ime:</strong>".$row['korime']."</span><br>
              <span><strong>Email:</strong>".$row['email']."</span><br>
              <span><strong>Lozinka:</strong>".$row['lozinka']."</span><br>
              <span><strong>Pripada medijskoj kući:</strong>".$row['medijska_kuca_naziv']."</span><br>
          </div>
        </div>
      ";
     $korisnik = $korisnik."
     <form action='newkorisnik.php' method='POST'>
     <input type='hidden' id='korisnik_id' name='korisnik_id' value=".$row['korisnik_id'].">
     <input type='hidden' id='editId' name='editId' value='1'>
     <button id='editButton' type='submit'>
       <i class='cart2'>
         <i class='fa-solid fa-edit'></i>
       </i>
     </button>
     </form>
     ";
     echo $korisnik;
    }
    ?>
  </div>
</section>

<section id="pagination" class="section-p1">
  <a href="?pageno=1">1</a>
  <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">
    <i class="fa-solid fa-arrow-left"> </i>
  </a>
  <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">
    <i class="fa-solid fa-arrow-right"> </i>
  </a>
  <a href="?pageno=<?php echo $total_pages; ?>">
    <?php echo $total_pages ?>
  </a>
</section>

<footer class="section-p1">
  <div class="col">
    <h4>Contact<h4>
      <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
      <p><strong>Phone:</strong> +042 390 804</p>
      <div class="follow">
        <h4> Follow us</h4>
        <div class="icon">
          <i class="fab fa-facebook-f"></i>
          <i class="fab fa-twitter"></i>
          <i class="fab fa-instagram"></i>
          <i class="fab fa-youtube"></i>
        </div>
      </div>
  </div>

<div class="copyright">
<p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>
</body>
</html>
