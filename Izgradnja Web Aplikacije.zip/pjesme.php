<?php
session_start();

    include("connection.php");
    include("functions.php");

    if(isset($_GET['pageno']))
    {
      $pageno = $_GET['pageno'];
    }
    else
    {
      $pageno = 1;
    }

    $medijska_kuca = '';
    $datum_Kupnje_od = null;
    $datum_kupnje_do = null;
    $vrijeme_kreiranje_od = null;
    $vrijeme_kreiranje_do = null;
    $prema_svidanjima = null;
    $pjesma_per_page = 10;
    $brojStr_offset = $pageno - 1;
    $offset = $brojStr_offset * $pjesma_per_page;
    $user_data = check_login($con);

    if(!empty($user_data))
    {
      $pjesme = allSongs($con);
      $broj_pjesmi = mysqli_num_rows($pjesme);
      $total_pages = ceil($broj_pjesmi / $pjesma_per_page);
      $pjesme_pagination = allSongs($con, $pjesma_per_page, $offset);

    }
    else
    {
      $pjesme = bought_songs_pagination($con);
      $broj_pjesmi = mysqli_num_rows($pjesme);
      $total_pages = ceil($broj_pjesmi / $pjesma_per_page);
      $pjesme_pagination = bought_songs_pagination($con, $pjesma_per_page, $offset);

    }

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {

      if(!empty($_POST['pjesme_medijska']))
      {
        $medijska_baza = findMedijska($con, $user_data['korisnik_id']);
        $medijska_kuca = $medijska_baza['naziv'];
      }
      else
      {
        $medijska_kuca = $_POST['medijska_kuca'];
        $datum_Kupnje_od = $_POST['datum_Kupnje_od'];
        $datum_kupnje_do = $_POST['datum_Kupnje_do'];
        $vrijeme_kreiranje_od = $_POST['vrijeme_kreiranje_od'];
        $vrijeme_kreiranje_do = $_POST['vrijeme_kreiranje_do'];
        if(!empty($_POST['prema_svidanjima']))
        {
          $prema_svidanjima = $_POST['prema_svidanjima'];
        }
        if(!empty($datum_Kupnje_od))
        {
          $datum_Kupnje_od = date('Y-m-d H:i:s', strtotime($datum_Kupnje_od));
        }
        if(!empty($datum_kupnje_do))
        {
          $datum_kupnje_do = date('Y-m-d H:i:s', strtotime($datum_kupnje_do));
        }
        if(!empty($vrijeme_kreiranje_od))
        {
          $vrijeme_kreiranje_od = date('Y-m-d H:i:s', strtotime($vrijeme_kreiranje_od));
        }
        if(!empty($vrijeme_kreiranje_do))
        {
          $vrijeme_kreiranje_do = date('Y-m-d H:i:s', strtotime($vrijeme_kreiranje_do));
        }
      }


      $pageno = 1;
      $pjesme = allSongs($con, null, null, $medijska_kuca, $datum_Kupnje_od, $datum_kupnje_do, $vrijeme_kreiranje_od, $vrijeme_kreiranje_do);
      $broj_pjesmi = mysqli_num_rows($pjesme);
      $total_pages = ceil($broj_pjesmi / $pjesma_per_page);
      $pjesme_pagination = allSongs($con, $pjesma_per_page, $offset, $medijska_kuca, $datum_Kupnje_od, $datum_kupnje_do, $vrijeme_kreiranje_od, $vrijeme_kreiranje_do, $prema_svidanjima);
    }




?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, inital-scale=1.0">
  <title>IWA</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css" integrity="sha512-bYPO5jmStZ9WI2602V2zaivdAnbAhtfzmxnEGh9RwtlI00I9s8ulGe4oBa5XxiC6tCITJH/QG70jswBhbLkxPw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js" integrity="sha512-AIOTidJAcHBH2G/oZv9viEGXRqDNmfdPVPYOYKGy3fti0xIplnlgMHUGfuNRzC6FkzIo0iIxgFnr9RikFxK+sw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js" integrity="sha256-6XMVI0zB8cRzfZjqKcD01PBsAy3FlDASrlC8SxCpInY=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js" integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php">Naslovna</a><li>
          <li><a href='pjesme.php' class='active'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>

  <section id="page-header">

    <h2>Uživajte u glazbi!</h2>

    <p>Ljetna akcija!</p>
  </section>
  <section id="product1" class="section-p1">
  <?php
    if(!empty($user_data))
    {
      $datum_Kupnje_do_display = '';
      $datum_kupnje_od_display = '';
      $vrijeme_kreiranje_od_display = '';
      $vrijeme_kreiranja_do_display = '';
      if(!empty($datum_kupnje_do))
      {
        $datum_Kupnje_do_display = date('d.m.Y H:i:s', strtotime($datum_kupnje_do));
      }
      if(!empty($datum_Kupnje_od))
      {
        $datum_kupnje_od_display = date('d.m.Y H:i:s', strtotime($datum_Kupnje_od));
      }
      if(!empty($vrijeme_kreiranje_od))
      {
        $vrijeme_kreiranje_od_display = date('d.m.Y H:i:s', strtotime($vrijeme_kreiranje_od));
      }
      if(!empty($vrijeme_kreiranje_do))
      {
        $vrijeme_kreiranja_do_display = date('d.m.Y H:i:s', strtotime($vrijeme_kreiranje_do));
      }


      echo "
      <h4>Filteri</h4><br>
      <form  action='pjesme.php' method='POST'>
        <div class='wrapper'>
          <div class='inline'>
            <label for='medijska_kuca'>Medijska kuća</label><br>
            <input type='text' placeholder='Medijska kuća' id='medijska_kuca' name='medijska_kuca' value='".$medijska_kuca."'/>
          </div>
          <div class='inline'>
            <label for='datum_Kupnje_od'>Datum kupnje od</label><br>
            <input type='text' class='datetime' placeholder='dd.mm.yyyy H:i:s' id='datum_Kupnje_od' name='datum_Kupnje_od' value='".$datum_kupnje_od_display."'/>
          </div>
          <div class='inline'>
            <label for='datum_Kupnje_do'>Datum kupnje do</label><br>
            <input type='text' class='datetime' placeholder='dd.mm.yyyy H:i:s' id='datum_Kupnje_do' name='datum_Kupnje_do' value='".$datum_Kupnje_do_display."'/>
          </div>
          <div class='inline'>
            <label for='vrijeme_kreiranje_od'>Vrijeme kreiranja od</label><br>
            <input type='text' class='datetime' placeholder='dd.mm.yyyy H:i:s' id='vrijeme_kreiranje_od' name='vrijeme_kreiranje_od' value='".$vrijeme_kreiranje_od."'/>
          </div>
          <div class='inline'>
            <label for='vrijeme_kreiranje_do'>Vrijeme kreiranja do</label><br>
            <input type='text' class='datetime' placeholder='dd.mm.yyyy H:i:s' id='vrijeme_kreiranje_do' name='vrijeme_kreiranje_do' value='".$vrijeme_kreiranja_do_display."'/>
          </div>
          <div class='inline'>
            <label for='prema_svidanjima'>Sortiraj prema sviđanjima</label><br>
            <input type='checkbox' placeholder='' id='prema_svidanjima' name='prema_svidanjima'/>
          </div>
        </div>
        <br>
        <div id='formbutton'>
          <button class='normal' type='submit'>Filtriraj</button>
        </div>
      </form>";
    }
  ?>
  <?php
    if(!empty($user_data) && $user_data['tip_korisnika']<=1 && $user_data['medijska_kuca'])
    {
      echo "<form  action='pjesme.php' method='POST' style='padding-top: 5px'>
        <div id='formbutton'>
          <input type='hidden' id='pjesme_medijska' name='pjesme_medijska' value=1/>
          <button class='normal' type='submit'>Pjesme medijske kuće</button>
        </div>
      </form>";
    }
  ?>
  </section>
  <section id="product1" class="section-p1">
        <div class="pro-container">
        <?php
          while($row = mysqli_fetch_array($pjesme_pagination))
          {
            $datum_vrijeme_kupnje_display = '';
            if(!empty($row['datum_vrijeme_kupnje']))
            {
              $datum_vrijeme_kupnje_display = date('d.m.Y H:i:s', strtotime($row['datum_vrijeme_kupnje']));
            }
            $datum_vrijeme_kreiranja_display = date('d.m.Y H:i:s', strtotime($row['datum_vrijeme_kreiranja']));
            $song =  "
          <div class='pro'>
            <img src='img/products/p1.png' alt='' />
            <div class='des'>
              <span><strong>Dodao korisnik: </strong>".$row['korime']."</span>
              <a href='pjesma.php?id=".$row['pjesma_id']."'>
                <h5>".$row['naziv']."</h5>
              </a>
            </div>
            <button>";
              $song = $song .
              "<div class='player'>
                <img src='img/play.png' id='".$row['poveznica']."' alt='' onclick='imageClick()'>
                <audio id= '".$row['poveznica']."-audio' >
                  <source src='".$row['poveznica']."' preload='none'>
                </audio>
              </div>
              </button>
              <div class='des'>
                <span><strong>Broj sviđanja: </strong>".$row['broj_svidanja']."</span><br>
                <span><strong>Opis pjesme: </strong>".$row['opis']."</span><br>
                <span><strong>Datum i vrijeme kreiranja: </strong>".$datum_vrijeme_kreiranja_display."</span><br>
                <span><strong>Datum i vrijeme kupnje: </strong>".$datum_vrijeme_kupnje_display."</span><br>";
                if($row['datum_vrijeme_kupnje'] == null && $row['medijska_kuca_id'] == null)
                {
                  $song = $song .
                  "<h4><strong>Status: </strong>Nekupljeno.</h4><br>";

                }
                if($row['datum_vrijeme_kupnje'] == null && $row['medijska_kuca_id'])
                {
                  $song = $song .
                  "<span class='colored'>
                  <strong>Status: </strong>Zatraženo.</span><br>
                  <span><strong>Zatražila kuća: </strong>".$row['naziv_medijska']."</span><br>";

                }
                if($row['datum_vrijeme_kupnje'] && $row['medijska_kuca_id'])
                {
                  $song = $song .
                  "<span><strong>Status: </strong>Kupljeno.</span><br>
                  <span><strong>Kupila kuća: </strong>".$row['naziv_medijska']."</span><br>";
                }
                $song = $song .
                "</div>
                </div>" ;

              ;
          echo $song;
          }

        ?>
      </div>
  </section>

  <section id="pagination" class="section-p1">
    <a href="?pageno=1">1</a>
    <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">
      <i class="fa-solid fa-arrow-left"> </i>
    </a>
    <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">
      <i class="fa-solid fa-arrow-right"> </i>
    </a>
    <a href="?pageno=<?php echo $total_pages; ?>">
      <?php echo $total_pages ?>
    </a>
  </section>

<footer class="section-p1">
    <div class="col">
      <h4>Contact<h4>
        <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
        <p><strong>Phone:</strong> +042 390 804</p>
        <div class="follow">
          <h4> Follow us</h4>
          <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
          </div>
        </div>
    </div>

<div class="copyright">
  <p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>
<script>
function imageClick(){
  var caller = imageClick.caller.arguments[0];
  var id = caller.currentTarget.id;

  var songPlayer = document.getElementById(id+'-audio');
  var image = document.getElementById(id);
  if(songPlayer.paused)
  {
    songPlayer.play();
    image.src = "img/pause.png";

  }else{
    songPlayer.pause();
    image.src="img/play.png"
  }
  };
</script>
</body>
<script>
$('.datetime').datetimepicker({
    format:'d.m.Y H:i:s',
});
</script>
</html>
