<?php

 function check_login($con)
 {

   if(isset($_SESSION['user_id']))
   {
     $id = $_SESSION['user_id'];
     $query = "select k.medijska_kuca_id as medijska_kuca, k.ime as ime, k.prezime as prezime, k.korime as korime, k.korisnik_id as korisnik_id, t.naziv as naziv, t.tip_korisnika_id as tip_korisnika from korisnik k join tip_korisnika t where k.tip_korisnika_id = t.tip_korisnika_id and k.korisnik_id = '$id' limit 1";

     $result = mysqli_query($con,$query);
     if($result && mysqli_num_rows($result) > 0)
     {

       $user_data = mysqli_fetch_assoc($result);
       return $user_data;
     }
 }

}

function random_num($length)
{

    $text = "";
    if($length < 5)
    {
      $length = 5;
    }

    $len = rand(4,$length);

    for($i=0; $i < $len; $i++) {

      $text .= rand(0,9);
    }

    return $text;
}

function bought_songs($con)
{

  $query = "select p.naziv, p.poveznica, p.broj_svidanja, m.korime, p.pjesma_id FROM pjesma p JOIN korisnik m ON m.korisnik_id = p.korisnik_id WHERE p.medijska_kuca_id is not NULL and p.datum_vrijeme_kupnje is not NULL ORDER BY p.broj_svidanja DESC LIMIT 5";
  $result = mysqli_query($con, $query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else{
    return $result;
    }
}

function bought_songs_pagination($con, $limit=NULL, $offset=NULL)
{
  $query = "select mk.naziv as naziv_medijska, p.pjesma_id, p.naziv, p.poveznica, p.opis, p.datum_vrijeme_kreiranja, p.datum_vrijeme_kupnje, p.broj_svidanja, p.medijska_kuca_id, m.korime FROM pjesma p JOIN korisnik m ON m.korisnik_id = p.korisnik_id LEFT JOIN medijska_kuca mk on p.medijska_kuca_id = mk.medijska_kuca_id WHERE p.medijska_kuca_id is not NULL and p.datum_vrijeme_kupnje is not NULL ORDER BY p.broj_svidanja DESC";
  $result = mysqli_query($con, $query);

  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else{
    return $result;
    }

}

function mysongs($con)
{
  $id = $_SESSION['user_id'];

  $query = "select mk.naziv as naziv_medijska, p.pjesma_id, p.naziv, p.poveznica, p.opis, p.datum_vrijeme_kreiranja, p.datum_vrijeme_kupnje, p.broj_svidanja, p.medijska_kuca_id, m.korime FROM pjesma p JOIN korisnik m ON m.korisnik_id = p.korisnik_id LEFT JOIN medijska_kuca mk on p.medijska_kuca_id = mk.medijska_kuca_id WHERE p.korisnik_id = '$id'";
  if(!empty($limit))
  {
    $query = $query . " LIMIT " . (int)$offset. "," . (int)$limit;
  }
  $result = mysqli_query($con, $query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else{
    return $result;
  }
}

function allSongs($con, $limit=null, $offset=null, $medijska_kuca_filter=null, $datum_Kupnje_od=null, $datum_kupnje_do=null, $vrijeme_kreiranje_od=null, $vrijeme_kreiranje_do=null, $sortiraj=null)
{

    $query = "select mk.naziv as naziv_medijska, p.pjesma_id, p.naziv, p.poveznica, p.opis, p.datum_vrijeme_kreiranja, p.datum_vrijeme_kupnje, p.broj_svidanja, p.medijska_kuca_id, m.korime FROM pjesma p JOIN korisnik m ON m.korisnik_id = p.korisnik_id LEFT JOIN medijska_kuca mk on p.medijska_kuca_id = mk.medijska_kuca_id";
    if(!empty($medijska_kuca_filter) || !empty($datum_Kupnje_od) || !empty($datum_kupnje_do) ||  !empty($vrijeme_kreiranje_od) || !empty($vrijeme_kreiranje_do))
    {
      $query = $query . " where ";

    }
    if(!empty($medijska_kuca_filter))
    {
      $query = $query . "mk.naziv = '$medijska_kuca_filter'";
    }

    if(!empty($datum_Kupnje_od))
    {
      if(!empty($medijska_kuca_filter))
      {
        $query = $query ."and ";
      }
      $query = $query . "p.datum_vrijeme_kupnje >= '$datum_Kupnje_od'";
    }

    if(!empty($datum_kupnje_do))
    {
      if(!empty($medijska_kuca_filter)||!empty($datum_Kupnje_od))
      {
        $query = $query ."and ";

      }

      $query = $query . "p.datum_vrijeme_kupnje <= '$datum_kupnje_do' ";
    }

    if(!empty($vrijeme_kreiranje_od))
    {
      if(!empty($medijska_kuca_filter)||!empty($datum_Kupnje_od)||!empty($datum_kupnje_do))
      {
        $query = $query ."and ";
      }

      $query = $query . "p.datum_vrijeme_kreiranja <= '$vrijeme_kreiranje_od'";
    }

    if(!empty($vrijeme_kreiranje_od))
    {
      if(!empty($medijska_kuca_filter)||!empty($datum_Kupnje_od)||!empty($datum_kupnje_do) || !empty($vrijeme_kreiranje_od))
      {
        $query = $query ."and ";
      }

      $query = $query . "p.datum_vrijeme_kreiranja <= '$vrijeme_kreiranje_od'";
    }

    if(!empty($sortiraj) && $sortiraj === 'on')
    {
      $query = $query . " order by p.broj_svidanja desc";
    }

    if(!empty($limit))
    {
      $query = $query . " LIMIT " . (int)$offset. "," . (int)$limit;
    }
    $result = mysqli_query($con, $query);
    if (!$result) {
      printf("Error: %s\n", mysqli_error($con));
      exit();
    }else{
      return $result;
    }
}

function findSong($con, $pjesmaId)
{
  $query = "select p.pjesma_id as pjesma_id, p.korisnik_id as korisnik_id, p.naziv as naziv, p.poveznica as poveznica, p.opis as opis, p.datum_vrijeme_kreiranja as vrijeme_kreiranja, p.datum_vrijeme_kupnje as vrijeme_kupnje, p.broj_svidanja as broj_svidanja, k.ime as korisnik_ime, k.prezime as korisnik_prezime, mk.naziv as medijska_kuca_naziv from pjesma p join korisnik k on p.korisnik_id=k.korisnik_id left join medijska_kuca mk on p.medijska_kuca_id = mk.medijska_kuca_id where p.pjesma_id =  '$pjesmaId' limit 1";
  $result = mysqli_query($con, $query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else{
    $pjesma_data =  mysqli_fetch_assoc($result);
    return $pjesma_data;
  }
}

function likeSong($con, $pjesmaId)
{
  $pjesma_data =  findSong($con, $pjesmaId);
  $brojSvidanja = $pjesma_data['broj_svidanja'] + 1;
  $query = "update pjesma set broj_svidanja='$brojSvidanja', datum_vrijeme_kreiranja = datum_vrijeme_kreiranja where pjesma_id = '$pjesmaId'";
  $result = mysqli_query($con,$query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }
}

function findMedijska($con, $korisnik_id)
{
  $query = "select k.medijska_kuca_id, mk.naziv from korisnik k join medijska_kuca mk on k.medijska_kuca_id = mk.medijska_kuca_id where k.korisnik_id = '$korisnik_id' limit 1";
  $result = mysqli_query($con,$query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else{
    $medijska_kuca = mysqli_fetch_assoc($result);
    return $medijska_kuca;
  }


}
function requestSong($con, $pjesmaId, $korisnik_id)
{
  $medijskaKuca = findMedijska($con, $korisnik_id);
  $medijskaID = $medijskaKuca['medijska_kuca_id'];
  $query = "update pjesma set medijska_kuca_id='$medijskaID', datum_vrijeme_kreiranja = datum_vrijeme_kreiranja where pjesma_id = '$pjesmaId'";
  $result = mysqli_query($con,$query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }
  else{
    return $result;
  }
}

function medijskeKuce($con)
{
  $query = "select medijska_kuca_id, naziv, opis from medijska_kuca";
  $result = mysqli_query($con,$query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else {
    return $result;
  }
}

function ukupnoSvidanja($con, $medijska_kuca_id)
{
  $query = "select sum(broj_svidanja) as ukupno_svidanja from pjesma where medijska_kuca_id='$medijska_kuca_id' limit 1";
  $result = mysqli_query($con,$query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else {
    $ukupno = mysqli_fetch_assoc($result);
    return $ukupno['ukupno_svidanja'];
  }

}

function findMedijskaKuca($con, $kucaId)
{
    $query = "select * from medijska_kuca where medijska_kuca_id =  '$kucaId' limit 1";
    $result = mysqli_query($con, $query);
    if (!$result) {
      printf("Error: %s\n", mysqli_error($con));
      exit();
    }else{
      $medijska_data =  mysqli_fetch_assoc($result);
      return $medijska_data;
    }
}

function allKorisnici($con, $limit=null, $offset=null)
{
  $query = "select
    k.korisnik_id as korisnik_id,
    k.tip_korisnika_id as tip_korisnika_id ,
    k.medijska_kuca_id as medijska_kuca_id,
    k.korime as korime,
    k.ime as ime,
    k.prezime as prezime,
    k.email as email,
    k.lozinka as lozinka,
    mk.naziv as medijska_kuca_naziv,
    t.naziv as tip_korisnika_naziv
    from korisnik k
    left join medijska_kuca mk
    on k.medijska_kuca_id = mk.medijska_kuca_id
    join tip_korisnika t on
    k.tip_korisnika_id = t.tip_korisnika_id";
  if(!empty($limit))
  {
    $query = $query . " LIMIT " . (int)$offset. "," . (int)$limit;
  }
  $result = mysqli_query($con, $query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else {
    return $result;
  }
}

function findKorisnik($con, $korisnikId)
{
  $query = "select
    k.korisnik_id as korisnik_id,
    k.tip_korisnika_id as tip_korisnika_id ,
    k.medijska_kuca_id as medijska_kuca_id,
    k.korime as korime,
    k.ime as ime,
    k.prezime as prezime,
    k.email as email,
    k.lozinka as lozinka,
    mk.naziv as medijska_kuca_naziv,
    t.naziv as tip_korisnika_naziv
    from korisnik k
    left join medijska_kuca mk
    on k.medijska_kuca_id = mk.medijska_kuca_id
    join tip_korisnika t on
    k.tip_korisnika_id = t.tip_korisnika_id
    where k.korisnik_id = '$korisnikId' limit 1";
  $result = mysqli_query($con, $query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else {
    $korisnik_data =  mysqli_fetch_assoc($result);
    return $korisnik_data;
  }
}

function tipoviKorisnika($con)
{
  $query = "select tip_korisnika_id, naziv from tip_korisnika";
  $result = mysqli_query($con,$query);
  if (!$result) {
    printf("Error: %s\n", mysqli_error($con));
    exit();
  }else {
    return $result;
  }
}
