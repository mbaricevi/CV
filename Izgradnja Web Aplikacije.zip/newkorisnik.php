<?php
session_start();

    include("connection.php");
    include("functions.php");

    $medijske_kuce = medijskeKuce($con);
    $tipovi_korisnika = tipoviKorisnika($con);
    $user_data = check_login($con);
    $korisnik_id = '';
    $korime_kor = '';
    $ime_kor = '';
    $prezime_kor = '';
    $email = '';
    $lozinka = '';
    $medijska_kuca_id = '';
    $tip_korisnika_id = '';

    if(empty($user_data) || (!empty($user_data) && $user_data['tip_korisnika']!=0))
    {
      printf("You do not have access to this page.");
      exit();
    }


    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
      if((!empty($_POST['editId'])))
      {
        $korisnikId = $_POST['korisnik_id'];
        $korisnik = findKorisnik($con, $korisnikId);
        $korisnik_id = $korisnik['korisnik_id'];
        $korime_kor = $korisnik['korime'];
        $ime_kor = $korisnik['ime'];
        $prezime_kor = $korisnik['prezime'];
        $email = $korisnik['email'];
        $lozinka = $korisnik['lozinka'];
        $medijska_kuca_id = $korisnik['medijska_kuca_id'];
        $tip_korisnika_id = $korisnik['tip_korisnika_id'];


      }
      else
      {

        if(!empty($_POST['korisnik_id']))
        {
          $korisnik_id = $_POST['korisnik_id'];
        }

        $korime_kor = $_POST['korime_kor'];
        $ime_kor = $_POST['ime_kor'];
        $prezime_kor = $_POST['prezime_kor'];
        $email = $_POST['email'];
        $lozinka = $_POST['lozinka'];
        $medijska_kuca_id = $_POST['medijska_kuca_id'];
        $tip_korisnika_id = $_POST['tip_korisnika_id'];

        if($tip_korisnika_id === '1' && $medijska_kuca_id === 'empty')
        {
          echo "Moderator mora imati medijsku kuću.";
        }
        elseif(!empty($korime_kor) && !empty($lozinka))
        {
          if($medijska_kuca_id==='empty')
          {
            $medijska_kuca_id=NULL;
          }

          if(!empty($korisnik_id))
          {
            $query = "update korisnik set korime='$korime_kor', ime='$ime_kor', prezime='$prezime_kor', email='$email', lozinka='$lozinka',";
            if($medijska_kuca_id)
            {
              $query = $query . "medijska_kuca_id='$medijska_kuca_id',";

            }
            else
            {
              $query = $query . "medijska_kuca_id=NULL,";
            }
            $query = $query."tip_korisnika_id='$tip_korisnika_id' where korisnik_id = $korisnik_id";
          }
          else
          {
            if($medijska_kuca_id==='empty')
            {
              $medijska_kuca_id=NULL;
            }

            $query = "insert into korisnik (korime,ime,prezime,email,lozinka,medijska_kuca_id,tip_korisnika_id) values ('$korime_kor','$ime_kor','$prezime_kor','$email','$lozinka',";
            if($medijska_kuca_id)
            {
              $query = $query . "'$medijska_kuca_id',";

            }
            else
            {
              $query = $query . "NULL,";
            }
            $query = $query . "'$tip_korisnika_id')";
          }
          printf($query);
          $result = mysqli_query($con, $query);
          if (!$result) {
            printf("Error: %s\n", mysqli_error($con));
            exit();
          }
          header("Location: svikorisnici.php");
          die;
        }else
        {
            echo "Please enter some valid information";
        }
      }
    }

?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, inital-scale=1.0">
  <title>IWA</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php">Naslovna</a><li>
          <li><a href='pjesme.php'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php' class='active'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>

 <div class="pro-container">
  <section id="product1" class=section-p1>
    <?php
      if($korisnik_id)
      {
        echo "<p>Uređuje se korisnik: ".$korime_kor."<p>";
      }
    ?>
    <form action="newkorisnik.php" method="post">

      <div id="newsongform">
      <?php
        if($korisnik_id)
        {
          echo "<input type='hidden' id='korisnik_id' name='korisnik_id' value=$korisnik_id>";
        }
      ?>
      <label class="fixedSet" for="korime_kor">Korisničko ime</label>
      <input type="text" placeholder="Korisničko ime" id="korime_kor" name="korime_kor" required value="<?php echo $korime_kor;?>"/><br>
      <label class="fixedSet" for="ime_kor">Ime</label>
      <input type="text" placeholder="Ime" id="ime_kor" name="ime_kor" required value="<?php echo $ime_kor;?>"/><br>
      <label class="fixedSet" for="prezime_kor">Prezime</label>
      <input type="text" placeholder="Prezime" id="prezime_kor" name="prezime_kor" required value="<?php echo $prezime_kor;?>"/><br>
      <label class="fixedSet" for="email">Email</label>
      <input type="text" placeholder="Email" id="email" name="email" value="<?php echo $email;?>"/><br>
      <label class="fixedSet" for="lozinka">Lozinka</label>
      <input type="text" placeholder="Lozinka" id="lozinka" name="lozinka" required value="<?php echo $lozinka;?>"/><br>
      <label class="fixedSet" for="medijska_kuca_id">Medijska kuca</label>
      <select name="medijska_kuca_id" id="medijska_kuca_id">

        <?php
        if(empty($medijska_kuca_id))
        {
          echo "<option value='empty' selected='selected'> </option>";
        }
        else
        {
          echo "<option value='empty'> </option>";
        }
        while($row=mysqli_fetch_array($medijske_kuce))
        {
          echo "<option value='".$row['medijska_kuca_id']."'";
          if($row['medijska_kuca_id']===$medijska_kuca_id)
          {
            echo "selected='selected' ";
          }
          echo ">".$row['naziv']."</option>";
        }
        ?>
      </select><br>
      <label class="fixedSet" for="tip_korisnika_id">Tip korisnika</label>
      <select name="tip_korisnika_id" id="tip_korisnika_id" required value="<?php echo $tip_korisnika_id?>">
        <?php
        while($row=mysqli_fetch_array($tipovi_korisnika))
        {
          echo "<option value='".$row['tip_korisnika_id']."'";
          if($row['tip_korisnika_id']===$tip_korisnika_id)
          {
            echo "selected='selected' ";
          }
          echo ">".$row['naziv']."</option>";
        }
        ?>
      </select><br>
      </div>
      <div id="formbutton">
        <button type="submit">Submit</button>
      </div>
    </form>

  </section>
</div>


  <footer class="section-p1">
    <div class="col">
      <h4>Contact<h4>
        <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
        <p><strong>Phone:</strong> +042 390 804</p>
        <div class="follow">
          <h4> Follow us</h4>
          <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
          </div>
        </div>
    </div>

<div class="copyright">
  <p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>
</body>
</html>
