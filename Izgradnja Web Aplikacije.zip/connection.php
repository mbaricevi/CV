<?php

$dbhost = "localhost";
$dbuser = "iwa_2021";
$dbpass = "foi2021";
$dbname = "iwa_2021_vz_projekt";

if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{
  die ("failed to connect!");
}
