<?php
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

    $naziv_pjesme = '';
    $opis_pjesme = '';
    $poveznica = '';
    $pjesma_id = '';
    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
      if((!empty($_POST['editId'])))
      {
        $pjesmaId = $_POST['songId'];
        $pjesma = findSong($con, $pjesmaId);
        $naziv_pjesme = $pjesma['naziv'];
        $opis_pjesme = $pjesma['opis'];
        $poveznica = $pjesma['poveznica'];
        $pjesma_id = $pjesma['pjesma_id'];

      }
      else
      {
        $naziv_pjesme = $_POST['naziv_pjesme'];
        $opis_pjesme = $_POST['opis_pjesme'];
        $poveznica = $_POST['poveznica'];
        $pjesmaId = $_POST['id_pjesma'];

        if(!empty($naziv_pjesme))
        {
          $user_id = $user_data['korisnik_id'];
          if(!empty($pjesmaId))
          {
            $query = "update pjesma set naziv='$naziv_pjesme', poveznica='$poveznica', opis='$opis_pjesme', datum_vrijeme_kreiranja = datum_vrijeme_kreiranja where pjesma_id = $pjesmaId";
          }
          else
          {
            $query = "insert into pjesma (korisnik_id,naziv,poveznica,opis) values ('$user_id','$naziv_pjesme','$poveznica','$opis_pjesme')";
          }

          mysqli_query($con,$query);
          header("Location: mojepjesme.php");
          die;
        }else
        {
            echo "Please enter some valid information";
        }
      }
    }

?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, inital-scale=1.0">
  <title>IWA</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php">Naslovna</a><li>
          <li><a href='pjesme.php'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php' class='active'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>

 <div class="pro-container">
  <section id="product1" class=section-p1>
    <?php
      if($pjesma_id)
      {
        echo "<p>Uređuje se pjesma: ".$naziv_pjesme."<p>";
      }
    ?>
    <form action="newsong.php" method="post">

      <div id="newsongform">
      <?php
        if($pjesma_id)
        {
          echo "<input type='hidden' id='id_pjesma' name='id_pjesma' value=$pjesma_id>";
        }
      ?>
      <label class="fixedSet" for="naziv_pjesme">Naziv pjesme</label>
      <input type="text" placeholder="Naziv pjesme" id="naziv_pjesme" name="naziv_pjesme" required value="<?php echo $naziv_pjesme;?>"/><br>
      <label class="fixedSet" for="poveznica">Poveznica</label>
      <input type="text" placeholder="Poveznica" id="poveznica" name="poveznica" required value="<?php echo $poveznica;?>"/><br>
      <label class="fixedSet" for="opis_pjesme">Opis pjesme</label>
      <input type="text" placeholder="Opis pjesme" id="opis_pjesme" name="opis_pjesme" required value="<?php echo $opis_pjesme;?>"/><br>
      </div>
      <div id="formbutton">
        <button type="submit">Submit</button>
      </div>
    </form>

  </section>
</div>


  <footer class="section-p1">
    <div class="col">
      <h4>Contact<h4>
        <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
        <p><strong>Phone:</strong> +042 390 804</p>
        <div class="follow">
          <h4> Follow us</h4>
          <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
          </div>
        </div>
    </div>

<div class="copyright">
  <p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>

</body>
</html>
