<?php
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);
    if(empty($user_data) || (!empty($user_data) && $user_data['tip_korisnika']!=0))
    {
      printf("You do not have access to this page.");
      exit();
    }



    $naziv_medijske_kuce = '';
    $opis_kuce = '';
    $medijska_kuca_id = '';

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
      if((!empty($_POST['editId'])))
      {
        $kucaId = $_POST['medijska_id'];
        $kuca = findMedijskaKuca($con, $kucaId);
        $naziv_medijske_kuce = $kuca['naziv'];
        $opis_kuce = $kuca['opis'];
        $medijska_kuca_id = $kuca['medijska_kuca_id'];

      }
      else
      {
        $naziv_medijske_kuce = $_POST['naziv_medijske_kuce'];
        $opis_kuce = $_POST['opis_kuce'];
        $medijska_kuca_id = $_POST['medijska_kuca_id'];

        if(!empty($naziv_medijske_kuce))
        {
          $user_id = $user_data['korisnik_id'];
          if(!empty($medijska_kuca_id))
          {
            $query = "update medijska_kuca set naziv='$naziv_medijske_kuce', opis='$opis_kuce' where medijska_kuca_id = $medijska_kuca_id";
          }
          else
          {
            $query = "insert into medijska_kuca (naziv,opis) values ('$naziv_medijske_kuce','$opis_kuce')";
          }

          mysqli_query($con,$query);
          header("Location: medijskekuce.php");
          die;
        }else
        {
            echo "Please enter some valid information";
        }
      }
    }

?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, inital-scale=1.0">
  <title>IWA</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php">Naslovna</a><li>
          <li><a href='pjesme.php'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php' class='active'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>

 <div class="pro-container">
  <section id="product1" class=section-p1>
    <?php
      if($medijska_kuca_id)
      {
        echo "<p>Uređuje se medijska kuća: ".$naziv_medijske_kuce."<p>";
      }
    ?>
    <form action="newmedijskakuca.php" method="post">

      <div id="newsongform">
      <?php
        if($medijska_kuca_id)
        {
          echo "<input type='hidden' id='medijska_kuca_id' name='medijska_kuca_id' value=$medijska_kuca_id>";
        }
      ?>
      <label class="fixedSet" for="naziv_medijske_kuce">Naziv medijske kuće</label>
      <input type="text" placeholder="Naziv medijske kuce" id="naziv_medijske_kuce" name="naziv_medijske_kuce" required value="<?php echo $naziv_medijske_kuce;?>"/><br>
      <label class="fixedSet" for="opis_kuce">Opis kuće</label>
      <input type="text" placeholder="Opis kuće" id="opis_kuce" name="opis_kuce" value="<?php echo $opis_kuce;?>"/><br>
      </div>
      <div id="formbutton">
        <button type="submit">Submit</button>
      </div>
    </form>

  </section>
</div>


  <footer class="section-p1">
    <div class="col">
      <h4>Contact<h4>
        <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
        <p><strong>Phone:</strong> +042 390 804</p>
        <div class="follow">
          <h4> Follow us</h4>
          <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
          </div>
        </div>
    </div>

<div class="copyright">
  <p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>

</body>
</html>
