 <?php
 session_start();

     include("connection.php");
     include("functions.php");

     $user_data = check_login($con);
 ?>

 <!DOCTYPE html>
 <html>
 <head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, inital-scale=1.0">
   <title>IWA</title>
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
   <link rel="stylesheet" href="style.css">
 </head>
 <body>
   <section id="header">

     <a href="logout.php">
       <?php
       if($user_data)
       {
         echo "Logout";
       }
       else
       {
         echo "Log in";
       }
       ?>
       </a>
     <?php if($user_data){
       $ime = $user_data['ime'];
       $prezime = $user_data['prezime'];
       $korime = $user_data['korime'];
       $naziv = $user_data['naziv'];
       $tip_korisnika = $user_data['tip_korisnika'];

       echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
       }else{
       echo "Hello, Guest";
       } ?>
       <div>
         <ul id="navbar">
           <li><a href="index.php">Naslovna</a><li>
           <li><a href='pjesme.php'>Pjesme</a><li>
           <?php
           if($user_data)
           {
             echo "<li><a href='mojepjesme.php'>Moje pjesme</a><li>";

             if($tip_korisnika<=0)
             {
                 echo "<li><a href='svikorisnici.php'>Svi korisnici</a><li>";
                 echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
             }

           }
           ?>
           <li><a href="o_autoru.php" class='active'>O autoru</a><li>
         </ul>
       </div>
   </section>

   <section id="about-head" class="section-p1">
     <img src="img/about/autor.jpg" alt="">
     <div>
       <h2>Baričević Matko - 0016132333 (46018/17-R) </h2><br>
       <h3><i>Student 3.godine PITUP-a. - Centar Varaždin - (2021./2022.)</i></h3>
       <p><br><br>
       Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ipsum a arcu cursus vitae congue mauris rhoncus aenean vel. Amet nisl suscipit adipiscing bibendum est ultricies. Egestas fringilla phasellus faucibus scelerisque eleifend donec pretium. Ullamcorper dignissim cras tincidunt lobortis. Nulla facilisi etiam dignissim diam quis enim lobortis scelerisque fermentum. Vitae aliquet nec ullamcorper sit amet risus. Pharetra massa massa ultricies mi quis hendrerit. Eu consequat ac felis donec et odio pellentesque. Vestibulum rhoncus est pellentesque elit. Ullamcorper sit amet risus nullam eget felis.<br><br><b>Kontaktirati na - mbaricevi@foi.hr</b></p>
       <br>

       <marquee bgcolor="#ccc" loop="-1" scrollamount="5" width="100%">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
       </marquee>
     </div>
   </section>

 <footer class="section-p1">
     <div class="col">
       <h4>Contact<h4>
         <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
         <p><strong>Phone:</strong> +042 390 804</p>
         <div class="follow">
           <h4> Follow us</h4>
           <div class="icon">
             <i class="fab fa-facebook-f"></i>
             <i class="fab fa-twitter"></i>
             <i class="fab fa-instagram"></i>
             <i class="fab fa-youtube"></i>
           </div>
         </div>
     </div>
 <div class="copyright">
   <p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
 </div>
 </footer>
 </body>
 </html>
