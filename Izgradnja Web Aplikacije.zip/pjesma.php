<?php
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);
    if(isset($_GET['id']))
    {
      $pjesmaId = $_GET['id'];
      $pjesma = findSong($con, $pjesmaId);
    }
    else
    {
      $pjesmaId = '';
    }

    $datum_vrijeme_kupnje_display = date('d.m.Y H:i:s', strtotime($pjesma['vrijeme_kupnje']));
    $datum_vrijeme_kreiranja_display = date('d.m.Y H:i:s', strtotime($pjesma['vrijeme_kreiranja']));

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
      $pjesmaId =$_POST['id_pjesma'];
      if(($_POST['id_pjesma']))
      {
        if($_POST['kupovina'])
        {
          requestSong($con, $pjesmaId, $user_data['korisnik_id']);
        }
        else
        {
          likeSong($con, $pjesmaId);
        }
        $pjesma = findSong($con, $pjesmaId);
      }
      $strLink = "pjesma.php"."?id=".$pjesmaId;
      header("Location: ".$strLink);
    }


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, inital-scale=1.0">
  <title>IWA</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php">Naslovna</a><li>
          <li><a href='pjesme.php' class='active'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>

  <section id="prodetails" class="section-p1">
    <div class="single-pro-image">
      <img src="img/products/p1.png" width="100%" id="MainImg" alt="">
    </div>
    <div class="single-pro-details">
      <h6><?php echo  "ID: ".$pjesma['pjesma_id']?></h6>
      <h4><?php echo  $pjesma['naziv']?></h4>
      <h6><?php echo  "Dodao: ".$pjesma['korisnik_ime']." ".$pjesma['korisnik_prezime']?></h6><br>

      <div class="wrapper">
      <div class="player">
        <img src='img/play.png' id='imgAudio' alt='' onclick='imageClick()' class='smaller'>
        <audio id= 'audio' >
          <source src=<?php echo $pjesma['poveznica']?> preload='none'>
        </audio>
      </div>
      <div>
      <?php
        if($user_data)
        {
          echo
          "<form action='pjesma.php' method='POST'>
            <input type='hidden' id='id_pjesma' name='id_pjesma' value='".$pjesma['pjesma_id']."'/>
            <button class='normal' type='submit'>
              <i class='cart2'>
                <i class='fa-solid fa-thumbs-up'></i>
                <i>Sviđa mi se !</i>
              </i>
            </button>
          <form>";
        }
      ?>
      </div>
      <br>
      <div style="padding-top:15px">
        <?php
        if(!empty($user_data) && $user_data['tip_korisnika']<2 && $user_data['medijska_kuca'] && $pjesma['vrijeme_kupnje'] == null && $pjesma['medijska_kuca_naziv'] == null)
        {
          echo
          "<form action=pjesma.php method='POST'>
          <input type='hidden' id='id_pjesma' name='id_pjesma' value=".$pjesma['pjesma_id']."/>
          <input type='hidden' id='kupovina' name='kupovina' value=1/>
          <button class='normal' type='submit'>
            <i class='cart'>
              <i class='fa-solid fa-cart-shopping'></i>
              <i>Zatraži pjesmu!</i>
            </i>
          </button>
          </form>";
        }
        ?>
      </div>

    </div>


      <h4>Detalji</h4>
      <h5><?php echo  "Broj sviđanja: ".$pjesma['broj_svidanja']?></h5><br>
      <h5><?php echo  "Datum i vrijeme kreiranja:  ".$datum_vrijeme_kreiranja_display?></h5><br>
      <?php if($pjesma['medijska_kuca_naziv']!='' &&  $pjesma['vrijeme_kupnje'])
            {
              echo "<h5>Kupila medijska kuća: ".$pjesma['medijska_kuca_naziv']."</h5><br>";
              echo "<h5>Datum i vrijeme kupnje: ".$datum_vrijeme_kupnje_display."</h5><br>";
            }
            if($pjesma['medijska_kuca_naziv']!='' && empty($pjesma['vrijeme_kupnje']))
            {
              echo "<h5>Zatrazila medijska kuća: ".$pjesma['medijska_kuca_naziv']."</h5><br>";
            }

      ?>
      <span><?php echo  $pjesma['opis']?></span>

    </div>
  </section>

<footer class="section-p1">
  <div class="col">
    <h4>Contact<h4>
      <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
      <p><strong>Phone:</strong> +042 390 804</p>
      <div class="follow">
        <h4> Follow us</h4>
        <div class="icon">
          <i class="fab fa-facebook-f"></i>
          <i class="fab fa-twitter"></i>
          <i class="fab fa-instagram"></i>
          <i class="fab fa-youtube"></i>
        </div>
      </div>
  </div>

<div class="copyright">
<p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>
<script>
function imageClick(){
  var songPlayer = document.getElementById('audio');
  var image = document.getElementById('imgAudio');
  if(songPlayer.paused)
  {
    songPlayer.play();
    image.src = "img/pause.png";

  }else{
    songPlayer.pause();
    image.src="img/play.png"
  }
  };
  </script>

</body>
</html>
