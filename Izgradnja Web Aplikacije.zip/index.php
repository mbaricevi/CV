<?php
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);
    $bought_songs = bought_songs($con);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, inital-scale=1.0">
  <title>IWA</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php" class='active'>Naslovna</a><li>
          <li><a href='pjesme.php'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>


  <section id="hero">
    <h4>Nove ponude!</h4>
    <h3>Zatražite prava na pjesmu!</h3>
    <h1>Dodajte nove kreacije!</h1>
    <button onclick="location.href='logout.php';">Ulogirajte se!</button>
  </section>

  <section id="feature" class="section-p1">
    <div class="fe-box">
        <img src="img/features/f1.png" alt"">
        <h6>Uživajte u glazbi!</h6>
    </div>
    <div class="fe-box">
        <img src="img/features/f2.png" alt"">
        <h6>Kupite pjesmu!</h6>
    </div>
    <div class="fe-box">
        <img src="img/features/f3.png" alt"">
        <h6>Zatražite prava!</h6>
    </div>
    <div class="fe-box">
        <img src="img/features/f6.png" alt"">
        <h6>Za pitanja, obratite se autoru stranice!</h6>
    </div>
  </section>

  <section id="product1" class="section-p1">
    <h2>Odabrane pjesme</h2>
      <p>Ljetna kolekcija</p>
      <div class="pro-container">
        <?php

         while($row = mysqli_fetch_array($bought_songs)){
          $song =  "
        <div class='pro'>
          <img src='img/products/p1.png' alt='' />
          <div class='des' onclick='window.location.href='sproduct.html';'>
            <span>Dodao korisnik: ".$row['korime']."</span>
            <span>Broj sviđanja: ".$row['broj_svidanja']."</span>
            <a href='pjesma.php?id=".$row['pjesma_id']."'>
              <h5>".$row['naziv']."</h5>
            </a>
          </div>
          <button>";
            $song = $song .
            "<div class='player'>
              <img src='img/play.png' id='".$row['poveznica']."' alt='' onclick='imageClick()'>
              <audio id= '".$row['poveznica']."-audio' >
                <source src='".$row['poveznica']."' preload='none'>
              </audio>
            </div>
            </button>
        </div>";
        echo $song;
        }
          ?>
      </div>
  </section>

  <footer class="section-p1">
    <div class="col">
      <h4>Contact<h4>
        <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
        <p><strong>Phone:</strong> +042 390 804</p>
        <div class="follow">
          <h4> Follow us</h4>
          <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
          </div>
        </div>
    </div>

<div class="copyright">
  <p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>
<script>
function imageClick(){
  var caller = imageClick.caller.arguments[0];
  var id = caller.currentTarget.id;

  var songPlayer = document.getElementById(id+'-audio');
  var image = document.getElementById(id);
  if(songPlayer.paused)
  {
    songPlayer.play();
    image.src = "img/pause.png";

  }else{
    songPlayer.pause();
    image.src="img/play.png"
  }
  };
</script>


</body>
</html>
