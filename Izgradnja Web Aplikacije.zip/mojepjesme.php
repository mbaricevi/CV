<?php
session_start();

    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

    if(empty($user_data))
    {
      printf("You do not have access to this page.");
      exit();
    }

    $bought_songs = mysongs($con);

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {

      $pjesma_id = $_POST['songId'];
      $akcija = $_POST['actionTaken'];

      if(!empty($pjesma_id) && !empty($akcija))
      {

        if($akcija === 'Odobreno')
        {
          $date = date('Y-m-d H:i:s');
          $query = "update pjesma p set p.datum_vrijeme_kupnje='$date' where p.pjesma_id = '$pjesma_id'";
        }
        if($akcija === 'Odbijeno')
        {
          $query = "update pjesma p set p.medijska_kuca_id=NULL where p.pjesma_id = '$pjesma_id'";
        }
        mysqli_query($con,$query);
        header("Location: mojepjesme.php");
        die;
      }else
      {
          echo "Please enter some valid information";
      }

    }
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, inital-scale=1.0">
  <title>IWA</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.1.2/css/all.css"/>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="header">

    <a href="logout.php">
      <?php
      if($user_data)
      {
        echo "Logout";
      }
      else
      {
        echo "Log in";
      }
      ?>
      </a>
    <?php if($user_data){
      $ime = $user_data['ime'];
      $prezime = $user_data['prezime'];
      $korime = $user_data['korime'];
      $naziv = $user_data['naziv'];
      $tip_korisnika = $user_data['tip_korisnika'];

      echo "Hello: $ime $prezime <strong>Username: $korime</strong> <strong>Vrsta: $naziv</strong>";
      }else{
      echo "Hello, Guest";
      } ?>
      <div>
        <ul id="navbar">
          <li><a href="index.php">Naslovna</a><li>
          <li><a href='pjesme.php'>Pjesme</a><li>
          <?php
          if($user_data)
          {
            echo "<li><a href='mojepjesme.php'  class='active'>Moje pjesme</a><li>";

            if($tip_korisnika<=0)
            {
                echo "<li><a href='svikorisnici.php'>Svi korisnici</a><li>";
                echo "<li><a href='medijskekuce.php'>Medijske kuće</a><li>";
            }

          }
          ?>
          <li><a href="o_autoru.php">O autoru</a><li>
        </ul>
      </div>
  </section>


  <section id="product1" class="section-p1">
    <a href="newsong.php">
      <button id ="ctasong2"><strong> Dodaj novu pjesmu </strong>
      </button>
    </a>
    <div class="pro-container">
      <?php
       while($row = mysqli_fetch_array($bought_songs)){
         $datum_vrijeme_kupnje_display = '';
         if(!empty($row['datum_vrijeme_kupnje']))
         {
           $datum_vrijeme_kupnje_display = date('d.m.Y H:i:s', strtotime($row['datum_vrijeme_kupnje']));
         }
         $datum_vrijeme_kreiranja_display = date('d.m.Y H:i:s', strtotime($row['datum_vrijeme_kreiranja']));
        $song =  "
      <div class='pro'>
        <img src='img/products/p1.png' alt='' />
        <div class='des'>
          <span><strong>Dodao korisnik: </strong>".$row['korime']."</span>
          <a href='pjesma.php?id=".$row['pjesma_id']."'>
            <h5>".$row['naziv']."</h5>
          </a>
        </div>";
          $song = $song .
          "<div class='player'>
            <img src='img/play.png' id='".$row['poveznica']."' alt='' onclick='imageClick()'>
            <audio id= '".$row['poveznica']."-audio' >
              <source src='".$row['poveznica']."' preload='none'>
            </audio>
          </div>
          </button>
          <div class='des'>
            <span><strong>Broj sviđanja: </strong>".$row['broj_svidanja']."</span><br>
            <span><strong>Opis pjesme: </strong>".$row['opis']."</span><br>
            <span><strong>Datum i vrijeme kreiranja: </strong>".$datum_vrijeme_kreiranja_display."</span><br>
            <span><strong>Datum i vrijeme kupnje: </strong>".$datum_vrijeme_kupnje_display."</span><br>";
            if($row['datum_vrijeme_kupnje'] == null && $row['medijska_kuca_id'] == null)
            {
              $song = $song .
              "<span><strong>Status: </strong>Nekupljeno.</span><br>";

            }
            if($row['datum_vrijeme_kupnje'] == null && $row['medijska_kuca_id'])
            {
              $song = $song .
              "<span><strong>Status: </strong>Zatraženo.</span><br>
              <span><strong>Zatražila kuća: </strong>".$row['naziv_medijska']."</span><br>
              <form action='mojepjesme.php' method='post' style='padding-top: 5px'>
              <input type = 'hidden' id = 'songId' name = 'songId' value = ".$row['pjesma_id'].">
              <input type = 'hidden' id = 'actionTaken' name = 'actionTaken' value = 'Odobreno'>
              <button id ='ctasong2' type='submit'><strong> Odobri </strong></button>
              </form>
              <form action='mojepjesme.php' method='post'  style='padding-top: 5px'>
              <input type = 'hidden' id = 'songId' name = 'songId' value = ".$row['pjesma_id'].">
              <input type = 'hidden' id = 'actionTaken' name = 'actionTaken' value = 'Odbijeno'>
              <button id ='ctasong2' type='submit'><strong> Odbij </strong></button>
              </form>
              ";

            }
            if($row['datum_vrijeme_kupnje'] && $row['medijska_kuca_id'])
            {
              $song = $song .
              "<span><strong>Status: </strong>Kupljeno.</span><br>
              <span><strong>Kupila kuća: </strong>".$row['naziv_medijska']."</span><br>";
            }
            $song = $song .
            "</div>";
            $song = $song .
            "</div>" ;
            if($user_data && $row['datum_vrijeme_kupnje'] == null && $row['medijska_kuca_id'] == null){
              $song = $song .
              "
              <form action='newsong.php' method='POST'>
              <input type='hidden' id='songId' name='songId' value=".$row['pjesma_id'].">
              <input type='hidden' id='editId' name='editId' value='1'>
              <button id='editButton' type='submit'>
                <i class='cart2'>
                  <i class='fa-solid fa-edit'></i>
                </i>
              </button>
              </form>
              ";
            }

          ;
      echo $song;
      }
        ?>
    </div>
</section>

<footer class="section-p1">
  <div class="col">
    <h4>Contact<h4>
      <p><strong>Address:</strong> Pavlinska ul. 2, 42000, Varaždin</p>
      <p><strong>Phone:</strong> +042 390 804</p>
      <div class="follow">
        <h4> Follow us</h4>
        <div class="icon">
          <i class="fab fa-facebook-f"></i>
          <i class="fab fa-twitter"></i>
          <i class="fab fa-instagram"></i>
          <i class="fab fa-youtube"></i>
        </div>
      </div>
  </div>

<div class="copyright">
<p>© 2022 Baričević Matko - Fakultet Organizacije i Informatike</p>
</div>
</footer>
    <script>
    function imageClick(){
      var caller = imageClick.caller.arguments[0];
      var id = caller.currentTarget.id;

      var songPlayer = document.getElementById(id+'-audio');
      var image = document.getElementById(id);
      if(songPlayer.paused)
      {
        songPlayer.play();
        image.src = "img/pause.png";

      }else{
        songPlayer.pause();
        image.src="img/play.png"
      }
    };
    </script>
</body>
</html>
